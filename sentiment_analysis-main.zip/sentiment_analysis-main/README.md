# sentiment_analysis
_April 2022_

Aspect-based sentiment analysis (ABSA) algorithm to identify product review categories and corresponding sentiment for each category.
